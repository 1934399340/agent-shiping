export interface ElectronAPI {
  selectFile: (options?: { filters?: Array<{ name: string; extensions: string[] }> }) => Promise<string[]>;
  selectFolder: () => Promise<string[]>;
  saveFile: (defaultName?: string) => Promise<string>;
}

declare global {
  interface Window {
    electronAPI: ElectronAPI;
  }
}
